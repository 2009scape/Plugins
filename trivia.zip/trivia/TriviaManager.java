package plugin.trivia;

import core.game.content.ItemNames;
import core.game.node.entity.player.Player;
import core.game.node.item.WeightedChanceItem;
import core.game.world.repository.Repository;
import core.plugin.InitializablePlugin;
import core.plugin.Plugin;
import core.tools.RandomFunction;
import plugin.CorePluginTypes.ManagerPlugin;
import plugin.CorePluginTypes.Managers;

@InitializablePlugin
public class TriviaManager extends ManagerPlugin {
    public static boolean hasSession,continuous = false;
    public static TriviaQuestion question;
    private static WeightedChanceItem[] rewards;

    @Override
    public void tick() {
        if(continuous && !hasSession){
            getNewQuestion();
            announce();
        }
    }

    public static void submit(Player player, String answer){
        if(answer.toLowerCase().equals(question.answer.toLowerCase())){
            Repository.sendNews(player.getUsername() + " has won the trivia question!");
            endSession();
            player.getInventory().add(RandomFunction.rollWeightedChanceTable(rewards));
        }
    }

    @Override
    public Plugin<Object> newInstance(Object arg) throws Throwable {
        Managers.register(this);
        TriviaQuestions.loadQuestions();

        rewards = new WeightedChanceItem[] {
                new WeightedChanceItem(ItemNames.COINS,1000,10),
                new WeightedChanceItem(ItemNames.COINS,50,100)
        };
        return this;
    }

    private static void getNewQuestion(){
        question = TriviaQuestions.getQuestion();
        hasSession = true;
    }

    private static void endSession(){
        hasSession = false;
    }

    public static void start(){
        if(!continuous){
            continuous = true;
        }
    }

    public static void stop(){
        continuous = false;
        hasSession = false;
    }

    public void announce(){
        Repository.sendNews(question.question);
    }
}
