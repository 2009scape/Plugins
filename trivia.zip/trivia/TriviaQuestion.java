package plugin.trivia;

public class TriviaQuestion {
    public String question,answer;
    public TriviaQuestion(String question, String answer){
        this.question = question;
        this.answer = answer;
    }
}
